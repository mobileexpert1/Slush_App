class LocaleText{
  // Intro Screen
  static const slushevent='Video-Speed Date Events';
  static const vidmeetswiping='Videos Meet Swiping';
  static const joindiverse="Break the ice through 3 minute face-to-face events. A whole new dating experience.";
  static const everything="Everything video. Share 15 second videos showing everyone who you are.";
  static const expressinterest ="Tap the like button to like someone, and if the feeling is mutual, it's a match!";

  //Slider
  static const likeMatch="Like, Match, Chat, and forge real meaningful connections.";

  //Login
  static const signIn="Sign in using your social account or email to continue.";

  //ForgotPassword
  static const pleaseprovide="Please provide your email. We will then send you a link to reset your password.";
  static const createPassword="Create your new password. If forgotten, you'll need to use the 'Forgot Password' option.";

  // Create New Account
  static const createNewAccount="Create an account to discover and connect with like-minded individuals near you.";

  // TIcket Screen
  static const EventDetail="You will virtually meet up to 10 different people. Each date will last 3 minutes and you will have an opportunity to decide whether or not you like the person. If you both like eachother, you will match at the end of the session and can continue your conversation. Most importantly, have fun!";

  static const aboutEvent='You will virtually meet up to 10 different people. Each date will last 3 minutes and you will have an opportunity to decide whether or not you like the person. If you both like eachother, you will match at the end of the session and can continue your conversation. Most importantly, have fun!';

  // static const guidetext1="The first thing you need to do is breathe and relax. Dates can be nerve-racking, but it only gets easier.\n\nSimply, tap the video-date button  below in order to begin your date.";
  static const guidetext1="The first thing you need to do is breathe and relax. Dates can be nerve-racking, but it only gets easier.";
  static const guidetext2="Your date has joined the call, don’t keep them waiting.";
  static const guidetext3="Oops... Your date has not shown up, your next date is in 2 minutes.";

  static const feedbackguide="I adore playing games, exploring new places Seeking genuine connections and someone to share life's beautiful moments with.";
  static const feedbackguide1='You had left the date early and we wanted to check everything is okay. Why did you leave the date early?';

  static const personDescription="My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading My name is Jessica Parker and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading";
  static const des="Confirm your identity by submitting a video. Once matched, you'll be verified.";
  static const des2="Someone caught your eye? Let them know with a Spark.";

}
