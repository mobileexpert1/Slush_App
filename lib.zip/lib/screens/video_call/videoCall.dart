import 'dart:async';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:agora_uikit/agora_uikit.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:slush/constants/color.dart';
import 'package:slush/constants/image.dart';
import 'package:slush/screens/video_call/video_call_controller.dart';
import 'package:slush/widgets/blue_button.dart';
import 'package:slush/widgets/bottom_sheet.dart';
import 'package:slush/widgets/text_widget.dart';

import '../../constants/localkeys.dart';
import 'feedback_screen.dart';

class VideoCallScreen extends StatefulWidget {
  const VideoCallScreen({Key? key}) : super(key: key);

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {


List reportingMatter = [
  "Did not have much in common",
  "Nudity / inappropriate",
  "Swearing / Aggression",
  "I have joined the wrong event",
  "I left the video-call by accident",
  "They are in the wrong event",
];
//


int selectedIndex = -1;



  bool camOnn=false;
  bool micOnn = false;
  Offset _floatingVideoOffset = Offset(20, 20);
  int _remoteUid = 0;
  bool _localUserJoined = false;
  static const appId = '1900d3ddc5e843279c1f8666c3618782';
  static const token = '007eJxTYOBlZ/Gznmuebbljm01H91apZM2+ojezHhsXH6/nNJuozKPAYGhpYJBinJKSbJpqYWJsZG6ZbJhmYWZmlmxsZmhhbmG0kbM2rSGQkeHZhsssjAwQCOKzMpSkFpcYMjAAAExdHH8=';
  static const channelId = 'test1';




  @override
  void initState() {
    super.initState();
    initializeAgora();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<TimerProvider>(context, listen: false).resetTimer();
      Provider.of<TimerProvider>(context, listen: false).startTimer();
    });
  }

  final AgoraClient client = AgoraClient(
  agoraConnectionData: AgoraConnectionData(
  appId: appId,
  channelName: channelId,
  tempToken: token,
  ),
  enabledPermission: [
  Permission.camera,
  Permission.microphone,
  ],
  );

  Future<void> initializeAgora() async {
    // Initialize the client
    await client.initialize();
  }

  @override
  void dispose() {
    client.engine.leaveChannel();
    client.release();
    super.dispose();
  }









// final AgoraClient _client = AgoraClient(agoraConnectionData: AgoraConnectionData(
//     appId: "1900d3ddc5e843279c1f8666c3618782",
//     channelName: "testing1",
//     tempToken:
//     "007eJxTYPjMqbvhl69JhIBacu6h+7K+k5xWMgl82Xc8LOrIzcXPIiYoMBhaGhikGKekJJumWpgYG5lbJhumWZiZmSUbmxlamFsYtbyqTmsIZGT4/6aVkZEBAkF8DoaS1OKSzLx0QwYGALusIXQ="
// ),
//   enabledPermission: [
//   Permission.camera,
//   Permission.microphone,
//   ],
//
// );





void _onExit() {
  client.release();
}



  @override
  Widget build(BuildContext context) {
    final timerProvider = Provider.of<TimerProvider>(context);
    final duration = timerProvider.duration;
    final formattedTime = "${duration.inMinutes.toString().padLeft(2, '0')}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}";

      if(formattedTime == "00:00"){
      print("disconnect");

      timerProvider.stopTimer();
      timerProvider.resetTimer();
      Get.back();
    }

    return Scaffold(
      backgroundColor: color.txtWhite,
      body:
      SafeArea(
        child: Stack(children: [

          AgoraVideoViewer(client: client,

            // layoutType: Layout.oneToOne,
            floatingLayoutContainerHeight: 160,
            floatingLayoutContainerWidth: 120,

            // key: Key("1"),
            layoutType: Layout.oneToOne,
            enableHostControls: true, // Add this to enable host controls
         renderModeType: RenderModeType.renderModeHidden,
            showAVState: true,
          ),
          Positioned(
            top: 16,
            right: 16,
            child: FloatingActionButton(
              backgroundColor: Colors.white,

              onPressed: () {
                // _client.sessionController.switchCamera();
              },
              child: Icon(Icons.switch_camera),
            ),
          ),
          AgoraVideoButtons(client: client,autoHideButtons: false,autoHideButtonTime: 5,enabledButtons: const [
            // BuiltInButtons.callEnd,
            // BuiltInButtons.toggleMic,
            // BuiltInButtons.toggleCamera,
          ],
            extraButtons: [
              GestureDetector(
                                      onTap: (){
                                        setState(() {micOnn=!micOnn;});
                                        // _engine.muteLocalAudioStream(micOnn);
                                        client.engine.muteLocalAudioStream(micOnn);



                                        }
                                      ,child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(
                                      micOnn? AssetsPics.micOff:AssetsPics.micOn))),
                                  //AssetsPics.microphoneOn:AssetsPics.microphone
                                  const SizedBox(width: 15),
              GestureDetector(
                                        onTap: (){
                                          if(formattedTime != "00:00"){
                                            customBuilderSheet(context, 'Is everything OK?',"Submit", heading: LocaleText.feedbackguide1,
                                                onTap: (){
                                                  timerProvider.stopTimer();
                                                  timerProvider.resetTimer();
                                                  // _engine.leaveChannel();
                                                  client.engine.leaveChannel();
                                                  _onExit();
                                                  print("disconnect");
                                                  Get.off(()=>const FeedbackVideoChatScreen());
                                                });


                                            //
                                            // Get.back();
                                          }
                                        },
                                        child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(AssetsPics.callCut))),
              const SizedBox(width: 15),
              GestureDetector(
                                      onTap: (){
                                        client.engine.muteLocalVideoStream(camOnn);
                                        setState(() {camOnn=!camOnn;});

                                      },
                                      child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(camOnn?AssetsPics.camOff:AssetsPics.camOn))),
                ]

          ),
         Align(
           alignment: Alignment.topCenter,
           child: Container(
             margin: EdgeInsets.only(top: 10),
             alignment: Alignment.center,
             height: 5.h,
             width: 27.w,
             decoration: BoxDecoration(
                 color: Colors.white30,
                 borderRadius: BorderRadius.circular(33)
             ),
             child: buildText(formattedTime, 25, FontWeight.w600, color.txtWhite),
           ),
         ),

                          Align(
                              alignment: Alignment.topRight,
                              child: GestureDetector(
                                  onTap: (){
                                    client.engine.switchCamera();
                                  },
                                  child: SizedBox(height: 26,width: 26, child: SvgPicture.asset(AssetsPics.camrotate)))),
        ],),
      ),
  //     Stack(
  //       children: [
  //         GestureDetector(
  //           onTap: (){
  //             setState(() {fullScreen=!fullScreen;});
  //           },
  //           child: SizedBox(
  //             height: size.height,
  //             width: size.width,
  //             child: Image.asset(AssetsPics.Videocallthumb,fit: BoxFit.cover),
  // // child: ZegoUIKitPrebuiltCall(appID: 1301213038, appSign: "827c61f1eb95ded9705847d8d75ea7ba3e8d29f77821ee7a134192eca3134241", userID: user_id, userName: user_name, callID: callID,
  // //               onDispose: () {// FirebaseFirestore.instance.collection('vc').doc(callID).set({'VideoCall': false}).then((value) => Navigator.pop(context));
  // //               },
  // //               config: ZegoUIKitPrebuiltCallConfig.oneOnOneVideoCall()..onOnlySelfInRoom = (_) {// FirebaseFirestore.instance.collection('vc').doc(callID).set({'VideoCall': false});
  // //                   return Navigator.pop(context);},),
  //           ),
  //         ),
  //         Positioned(
  //           right: 25.0,
  //           bottom:fullScreen?50.0:TargetPlatform.iOS==defaultTargetPlatform?150.0: 120.0,
  //           child: Container(
  //             height: 18.h,
  //             width: 24.w,
  //             decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),
  //               color: Colors.white,
  //             ),
  //           ),
  //         ),
  //         SafeArea(
  //           child: Column(children: [
  //             AnimatedContainer(
  //               duration: const Duration(milliseconds: 500),
  //               padding: const EdgeInsets.only(left: 18,right: 20,top: 10),
  //               height: fullScreen?0:6.h,
  //               decoration:  BoxDecoration(
  //                 boxShadow: [
  //                   BoxShadow(color: Colors.transparent, blurRadius:fullScreen?0: 90.0,
  //                     spreadRadius:fullScreen?0: 60.0, offset:fullScreen?const Offset(0.0, 0.0): const Offset(50.0, 1.0),)
  //                 ],
  //               ),
  //               width: size.width,
  //               child: Row(
  //                 mainAxisAlignment: MainAxisAlignment.end,
  //                 children: [
  //                 SizedBox(height: 26,width: 26, child: SvgPicture.asset(AssetsPics.camrotate)),
  //               ],),
  //             ),
  //             AnimatedContainer(
  //               duration: const Duration(milliseconds: 500),
  //               height: fullScreen?0:6.h,
  //               child: Container(
  //                 alignment: Alignment.center,
  //                 height: 6.h,
  //                 width: 38.w,
  //                 decoration: BoxDecoration(
  //                     color: Colors.white30,
  //                     borderRadius: BorderRadius.circular(33)
  //                 ),
  //                 child: buildText(formatDuration(Duration(seconds: _secondsLeft)), 29, FontWeight.w600, color.txtWhite),
  //               ),
  //             ),
  //             const Spacer(),
  //             AnimatedContainer(
  //               duration: const Duration(milliseconds: 500),
  //               padding: EdgeInsets.only(left: 18,right: 20,top: 10,bottom:fullScreen?0: 30),
  //               height:fullScreen?0: 15.h,
  //               decoration:  BoxDecoration(
  //                 boxShadow: [
  //                   BoxShadow(color: Colors.transparent,
  //                     blurRadius:fullScreen?0: 90.0, spreadRadius:fullScreen?0: 60.0, offset:fullScreen?const Offset(0.0, 0.0): const Offset(50.0, 1.0),)
  //                 ],
  //               ),
  //               width: size.width,
  //               child: Row(
  //                 mainAxisAlignment: MainAxisAlignment.center,
  //                 children: [
  //                   GestureDetector(
  //                       onTap: (){
  //                         setState(() {micOnn=!micOnn;});
  //                         // Get.to(()=>const FeedbackVideoChatScreen());
  //                         }
  //                       ,child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(
  //                       micOnn? AssetsPics.micOn:AssetsPics.micOff))),
  //                   //AssetsPics.microphoneOn:AssetsPics.microphone
  //                   const SizedBox(width: 15),
  //                   GestureDetector(
  //                       onTap: (){
  //                         if(_secondsLeft<=0){
  //                           customBuilderSheet(context, 'Is everything OK?',"Submit", heading: LocaleText.feedbackguide1,
  //                           onTap: (){
  //                             Get.off(()=>const FeedbackVideoChatScreen());
  //                           });
  //                         }else{
  //                           Get.off(()=>const FeedbackVideoChatScreen());
  //                         }
  //                       },
  //                       child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(AssetsPics.callCut))),
  //                   const SizedBox(width: 15),
  //                   GestureDetector(
  //                       onTap: (){
  //                         setState(() {camOnn=!camOnn;});
  //                       },
  //                       child: SizedBox(height: 60,width: 60, child: SvgPicture.asset(camOnn?AssetsPics.camOn:AssetsPics.camOff))),
  //                 ],),
  //             )
  //           ],),
  //         )
  //       ],
  //     )
    );
  }





customBuilderSheet(BuildContext context,String title, String btnTxt, {
      required String heading,
      VoidCallback? onTapp = pressed,
      VoidCallback? onTap = pressed,
      bool? forAdvanceTap}) {
  return showGeneralDialog(
      barrierLabel: "Label",
      transitionDuration: const Duration(milliseconds: 500),
      context: context,
      pageBuilder: (context, anim1, anim2) {
        return GestureDetector(
          onTap: pressed,
        // return WillPopScope(
        //   onWillPop: () async => false,
          child: Scaffold(
            backgroundColor: Colors.transparent,
            body: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                  height: MediaQuery.of(context).size.height / 1.65,
                  width: MediaQuery.of(context).size.width / 1.1,
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: color.txtWhite,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const SizedBox(height: 10),
                      buildText(title, 20, FontWeight.w600, color.txtBlack),
                      buildText2(heading, 18, FontWeight.w500, color.txtgrey,
                          fontFamily: FontFamily.hellix),
                      Expanded(
                        child: StatefulBuilder(
                            builder: (BuildContext context, StateSetter setState) {
                              return ListView.builder(
                                  itemCount: reportingMatter.length,
                                  itemBuilder: (context, index) {
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 10),
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            selectedIndex = index;
                                          });
                                        },
                                        child: Row(
                                          children: [
                                            CircleAvatar(
                                              backgroundColor:
                                              selectedIndex == index ? color.txtBlue : color.txtBlack,
                                              radius: 9,
                                              child: CircleAvatar(
                                                radius: 8,
                                                backgroundColor: selectedIndex == index ? color.txtWhite : color.txtWhite,
                                                // backgroundImage: SvgPicture.asset(AssetsPics.arrowLeft),
                                                child: selectedIndex == index
                                                    ? SvgPicture.asset(AssetsPics.blueTickCheck, fit: BoxFit.cover,) : const SizedBox(),
                                              ),
                                            ),
                                            const SizedBox(width: 10,),
                                            buildText2(reportingMatter[index], 18,
                                                FontWeight.w500, color.txtgrey,
                                                fontFamily: FontFamily.hellix),
                                          ],
                                        ),
                                      ),
                                    );
                                  });
                            }),
                      ),
                      const SizedBox(height: 15),
                      blue_button(context, btnTxt, press: onTap)
                    ],
                  )),
            ),
          ),
        );
      },
      transitionBuilder: (context, anim1, anim2, child) {
        return SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: const Offset(0, 0))
              .animate(anim1),
          child: child,
        );
      });
}


}


