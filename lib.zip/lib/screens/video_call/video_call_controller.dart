import 'dart:async';
import 'package:flutter/material.dart';

class TimerProvider with ChangeNotifier {
  Duration _duration = const Duration(minutes: 3);
  Timer? _timer;

  Duration get duration => _duration;

  void startTimer() {
    _timer?.cancel();  // Cancel any existing timer
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_duration.inSeconds > 0) {
        _duration -= const Duration(seconds: 1);
        print('Time remaining: ${_duration.inMinutes}:${_duration.inSeconds % 60}');  // Debugging output
        notifyListeners();
      } else {
        _timer?.cancel();
        print('Timer finished');
      }
    });
  }

  void stopTimer() {
    _timer?.cancel();
    print('Timer stopped');
  }

  void resetTimer() {
    _timer?.cancel();
    _duration = const Duration(minutes: 3);
    notifyListeners();
    print('Timer reset to 03:00');
  }
}